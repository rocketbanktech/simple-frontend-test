import "./App.scss";
import Routes from "./Routes";

const App = () => <Routes />;

export default App;
